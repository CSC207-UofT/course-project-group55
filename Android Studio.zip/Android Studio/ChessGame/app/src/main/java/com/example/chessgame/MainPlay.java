package com.example.chessgame;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * This Activity is the first one seen when opening the app. Defines multiple buttons referenced in
 * .XML file. Hotseat leads to functional 1 v 1 Chess Game. Demos leads to fully functional tests
 * for various chess features .As of now, LAN lacks functionality in GUI.
 *
 * Matthew MacQuarrie-Cottle
 * 2021/12/08
 */

public class MainPlay extends AppCompatActivity {

    private Button hotseat;
    private Button lan;
    private Button demos;

    /**
     *Sets the activity on the screen. Creates buttons and overrides OnClick behaviour for each
     * button.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_play);

        hotseat = (Button) findViewById(R.id.hotseat);
        hotseat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityHotseat();
            }
        });

        lan = (Button) findViewById(R.id.lan);
        lan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openActivityLan(); }
        });

        demos = (Button) findViewById(R.id.demos);
        demos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openActivityDemos(); }
        });

    }

    /**
     * Defines methods used to open new Activity and define appropriate use of Transition Animation.
     */

    public void openActivityHotseat() {
        Intent intent = new Intent(this, MainHotseat.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }

    public void openActivityLan() {
        Intent intent = new Intent(this, MainLan.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }

    private void openActivityDemos() {
        Intent intent = new Intent(this, MainDemos.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }
}