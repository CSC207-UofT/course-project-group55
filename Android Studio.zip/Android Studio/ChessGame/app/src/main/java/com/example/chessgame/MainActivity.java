package com.example.chessgame;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * This Activity is the first one seen when opening the app. Defines multiple buttons referenced in
 * .XML file. As of now, Login and Settings lack functionality.
 *
 * Matthew MacQuarrie-Cottle
 * 2021/12/08
 */


public class MainActivity extends AppCompatActivity {
    private Button play;
    private Button login;
    private Button settings;

    /**
     * Sets the activity on the screen. Creates buttons and overrides OnClick behaviour for each
     * button.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        play = (Button) findViewById(R.id.play);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityPlay();
            }
        });

        login = (Button) findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityLogin();
            }
        });

        settings = (Button) findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitySettings();
            }
        });
    }

    /**
     * Defines methods used to open new Activity and define appropriate use of Transition Animation.
     */


    public void openActivityPlay() {
        Intent intent = new Intent(this,  MainPlay.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }

    public void openActivityLogin() {
        Intent intent = new Intent(this, MainLogin.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }

    public void openActivitySettings() {
        Intent intent = new Intent(this, MainSettings.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }
}
