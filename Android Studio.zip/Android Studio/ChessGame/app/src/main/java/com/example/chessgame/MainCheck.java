package com.example.chessgame;


import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.chessgame.main.java.chess.*;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * This Activity displays the 1 v 1 Chess Game Check demo. Initializes game with a predetermined
 * board state ideal for testing. See MainHotseat.java for further documentation.
 *
 * Matthew MacQuarrie-Cottle
 * 2021/12/08
 */

public class MainCheck extends AppCompatActivity {
    Map<Coord, ImageButton> imageButtons = new HashMap<>();
    private ChessGame game;
    private playerColor currColor;
    Set<Coord> prevLegalMoves = new HashSet<>();
    ImageView whitePlayer;
    ImageView blackPlayer;
    Coord prevKingLocation = new Coord(0, 0);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_check);
        String[] playerNames = new String[2];
        playerNames[1] = "Player 2";
        playerNames[0] = "Player 1";
        game = new ChessGame(playerNames,"rnbqkbnr/pp2p1pp/8/2pp1p2/3PPP2/8/PPP3PP/RNBQKBNR w KQkq - 0 1");
        currColor = null;

        whitePlayer = (ImageView) findViewById(R.id.White);
        blackPlayer = (ImageView) findViewById(R.id.Black);

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                Coord coord = new Coord(i, j);
                String name = coord.letterCoord();
                ImageButton button = (ImageButton) findViewById(getResources().getIdentifier(name, "id", this.getPackageName()));
                imageButtons.put(coord, button);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        game.selectCoord(coord);

                        if (game.promoting()){
                            if (game.currColor().equals(playerColor.White)){
                                promotionActivity(v);}
                            else{
                                promotionActivityBlack(v);
                            }
                        }
                        else{
                            game.confirmTurn();
                        }

                        kingCheck();

                        if (game.isGameOver()) {
                            winCheck(v, game.gameOverMessage());
                        }

                        displayLegal(game.getCurrLegalMoves());

                        if (game.currColor() != currColor) {
                            currColor = game.currColor();
                            updateBoard();
                        }
                    }

                    private void winCheck(View v, String result) {
                        LayoutInflater inflater = (LayoutInflater)
                                getSystemService(LAYOUT_INFLATER_SERVICE);
                        View popupView = inflater.inflate(R.layout.winner, null);

                        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                        final PopupWindow popupWindow = new PopupWindow(popupView, width, height);
                        popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);

                        RelativeLayout background = (RelativeLayout) popupView.findViewById(R.id.winner_background);
                        TextView winner = (TextView) popupView.findViewById(R.id.winner_text);


                        if (result.equals("black")){
                            background.setBackgroundColor(Color.parseColor("#FF555555"));
                            winner.setTextColor(Color.parseColor("#FFFFFFFF"));
                            winner.setText(R.string.BlackWins);

                        }

                        if (result.equals("white")){
                            background.setBackgroundColor(Color.parseColor("#FFDDDDDD"));
                            winner.setTextColor(Color.parseColor("#FF000000"));
                            winner.setText(R.string.WhiteWins);
                        }

                        else{
                            background.setBackgroundColor(Color.parseColor("#FF000000"));
                            winner.setTextColor(Color.parseColor("#FFFFFFFF"));
                            winner.setText(R.string.draw);
                        }
                    }

                    private void promotionActivityBlack(View v) {

                        LayoutInflater inflater = (LayoutInflater)
                                getSystemService(LAYOUT_INFLATER_SERVICE);
                        View popupView = inflater.inflate(R.layout.promote_pop_black, null);

                        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                        final PopupWindow popupWindow = new PopupWindow(popupView, width, height);
                        popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);

                        ImageButton queen = (ImageButton) popupView.findViewById(R.id.q);
                        ImageButton knight = (ImageButton) popupView.findViewById(R.id.n);
                        ImageButton rook = (ImageButton) popupView.findViewById(R.id.r);
                        ImageButton bishop = (ImageButton) popupView.findViewById(R.id.b);
                        HashSet empty = new HashSet<>();

                        queen.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                game.promotePawnTo('q');
                                game.confirmTurn();
                                updateBoard();
                                displayLegal(empty);
                                popupWindow.dismiss();
                            }
                        });

                        knight.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                game.promotePawnTo('n');
                                game.confirmTurn();
                                updateBoard();
                                displayLegal(empty);
                                popupWindow.dismiss();
                            }
                        });

                        rook.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                game.promotePawnTo('r');
                                game.confirmTurn();
                                updateBoard();
                                displayLegal(empty);
                                popupWindow.dismiss();
                            }
                        });

                        bishop.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                game.promotePawnTo('b');
                                game.confirmTurn();
                                updateBoard();
                                displayLegal(empty);
                                popupWindow.dismiss();
                            }
                        });
                    }

                    public void promotionActivity(View v) {



                        LayoutInflater inflater = (LayoutInflater)
                                getSystemService(LAYOUT_INFLATER_SERVICE);
                        View popupView = inflater.inflate(R.layout.promote_pop, null);

                        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                        final PopupWindow popupWindow = new PopupWindow(popupView, width, height);

                        popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);

                        ImageButton queen = (ImageButton) popupView.findViewById(R.id.q);
                        ImageButton knight = (ImageButton) popupView.findViewById(R.id.n);
                        ImageButton rook = (ImageButton) popupView.findViewById(R.id.r);
                        ImageButton bishop = (ImageButton) popupView.findViewById(R.id.b);
                        HashSet empty = new HashSet<>();

                        queen.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                game.promotePawnTo('q');
                                game.confirmTurn();
                                updateBoard();
                                displayLegal(empty);
                                popupWindow.dismiss();
                            }
                        });

                        knight.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                game.promotePawnTo('n');
                                game.confirmTurn();
                                updateBoard();
                                displayLegal(empty);
                                popupWindow.dismiss();
                            }
                        });

                        rook.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                game.promotePawnTo('r');
                                game.confirmTurn();
                                updateBoard();
                                displayLegal(empty);
                                popupWindow.dismiss();
                            }
                        });

                        bishop.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                game.promotePawnTo('b');
                                game.confirmTurn();
                                updateBoard();
                                displayLegal(empty);
                                popupWindow.dismiss();
                            }
                        });

                    }
                });
            }

        }
        updateBoard();
    }

    private void kingCheck() {
        if (game.isChecked()) {
            imageButtons.get(game.kingCoord()).setBackgroundColor(Color.parseColor("#FFF55956"));
            prevKingLocation = game.kingCoord();
        }

        else{
            if ((prevKingLocation.x + prevKingLocation.y) % 2 == 0) {
                imageButtons.get(prevKingLocation).setBackground(getDrawable(R.drawable.dark_space_highlight));
            }
            else {
                imageButtons.get(prevKingLocation).setBackground(getDrawable(R.drawable.light_space_highlight));
            }
        }
    }

    private void displayLegal(Set<Coord> currLegalMoves) {
        if (!prevLegalMoves.isEmpty()){
            for (Coord coord2: prevLegalMoves){
                if ((coord2.x + coord2.y) % 2 == 0) {
                    imageButtons.get(coord2).setBackground(getDrawable(R.drawable.dark_space_highlight));
                }
                else {
                    imageButtons.get(coord2).setBackground(getDrawable(R.drawable.light_space_highlight));
                }
            }}
        for (Coord coord1: currLegalMoves) {
            if ((coord1.x + coord1.y) % 2 == 0) {
                imageButtons.get(coord1).setBackgroundColor(Color.parseColor("#FF9E9344"));
            }
            else{
                imageButtons.get(coord1).setBackgroundColor(Color.parseColor("#FFEBE094"));
            }
        }
        prevLegalMoves = currLegalMoves;
    }

    private void updateBoard() {
        if (game.currColor().equals(playerColor.White)) {
            blackPlayer.setBackgroundColor(Color.parseColor("#FF555555"));
            whitePlayer.setBackgroundColor(Color.parseColor("#FFEBE094"));

        }

        else{
            whitePlayer.setBackgroundColor(Color.parseColor("#FFDDDDDD"));
            blackPlayer.setBackgroundColor(Color.parseColor("#FF9E9344"));
        }
        for (Coord coord: imageButtons.keySet()
        ) {
            imageButtons.get(coord).setImageResource(0);
            String piece;
            if (game.board.pieceAt(coord) != null){
                piece = ("" + game.board.pieceAt(coord).FENChar()).toLowerCase();
                if (game.board.pieceAt(coord).color() == playerColor.White){
                    piece = "w"  + piece;
                }
                imageButtons.get(coord).setImageResource(getResources(). getIdentifier("drawable/" + piece, null, this.getPackageName()));
            }

        }
    }
}
