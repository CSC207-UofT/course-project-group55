package com.example.chessgame;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * This Activity display options for various Demo scenarios. Defines multiple buttons referenced in
 * .XML file.
 *
 * Matthew MacQuarrie-Cottle
 * 2021/12/08
 */

public class MainDemos extends AppCompatActivity {

    private Button castling;
    private Button check;
    private Button promoting;
    private Button enPassant;

    /**
     * Sets the activity on the screen. Creates buttons and overrides OnClick behaviour for each
     * button.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_demos);

        castling = (Button) findViewById(R.id.castling);
        castling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openActivityCastling(); }
        });

        check = (Button) findViewById(R.id.check);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openActivityCheck(); }
        });

        promoting = (Button) findViewById(R.id.promoting);
        promoting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openActivityPromoting(); }
        });

        enPassant = (Button) findViewById(R.id.en_passant);
        enPassant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openActivityEnPassant(); }
        });

    }

    /**
     * Defines methods used to open new Activity and define appropriate use of Transition Animation.
     */

    public void openActivityCastling() {
        Intent intent = new Intent(this, MainCastle.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }

    public void openActivityCheck() {
        Intent intent = new Intent(this, MainCheck.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }

    private void openActivityPromoting() {
        Intent intent = new Intent(this, MainPromote.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }

    private void openActivityEnPassant() {
        Intent intent = new Intent(this, MainEnPassant.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }

}