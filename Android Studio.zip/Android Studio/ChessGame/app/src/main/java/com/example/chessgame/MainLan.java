package com.example.chessgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/**
 * This Activity is a placeholder for potential LAN implementation in the future. Text fields and
 * Buttons lack functionality.
 *
 * Matthew MacQuarrie-Cottle
 * 2021/12/08
 */

public class MainLan extends AppCompatActivity {

    /**
     * Sets the activity on the screen.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_lan);
    }
}