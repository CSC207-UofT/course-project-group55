package com.example.chessgame.main.java.chess;

public class ChessMoveRecord {

}
