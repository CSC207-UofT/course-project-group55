package com.example.chessgame.main.java.chess;

public enum PieceRole {
    King,
    Queen,
    Rook,
    Knight,
    Bishop,
    Pawn;
}
