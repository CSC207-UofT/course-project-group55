package com.example.chessgame.main.java.chess;

public class ChessPGNReader {
    private Chessboard board;

    ChessPGNReader(Chessboard board){

    }

}
